% Code for NVMD infrared small target detection
% Author: Xiaoyang Wang
% Date: Dec, 2016
% Derived from the 2D-VMD code (See below)
% If you find this code useful, please cite:
% " Wang, X., Peng, Z., Zhang, P. and He, Y., 2017. Infrared Small Target Detection via Nonnegativity-Constrained Variational Mode Decomposition. 
% IEEE Geoscience and Remote Sensing Letters, 14(10), pp.1700-1704."


%-------------------------------------------------------------------------
% Test script for 2D-VMD
% Authors: Konstantin Dragomiretskiy and Dominique Zosso
% {konstantin,zosso}@math.ucla.edu
% http://www.math.ucla.edu/~{konstantin,zosso}
% Initial release 2014-03-17 (c) 2014
%
% When using this code, please do cite our papers:
% -----------------------------------------------
% K. Dragomiretskiy, D. Zosso, Variational Mode Decomposition, IEEE Trans.
% on Signal Processing, 62(3):531-544, 2014. DOI:10.1109/TSP.2013.2288675
%
% K. Dragomiretskiy, D. Zosso, Two-Dimensional Variational Mode
% Decomposition, IEEE Int. Conf. Image Proc. (submitted). Preprint
% available here: ftp://ftp.math.ucla.edu/pub/camreport/cam14-16.pdf
%

%% preparations

close all;
clc;
clear all;


[filename pathname]=uigetfile('*.bmp;*.jpg;*.png;','Select the file');
f=imread([pathname ,filename]);

imshow(f);
% [x y]=ginput(1);
[width height ch]=size(f);
if ch==3
f=rgb2gray(f);
end
f=double(f);

img_in=f;

%% Difference of Gaussian Filter
sigma1=0.5;
sigma2=2.0;
f1=fspecial('gaussian',5,sigma1);
f2=fspecial('gaussian',5,sigma2);
I1=imfilter(img_in,f1,'replicate');
I2=imfilter(img_in,f2,'replicate');

f=I1-I2;

f(f<0) = 0;
%% parameters:
alpha = 200;       % bandwidth constraint
tau = 5;         % Lagrangian multipliers dual ascent time step
K = 3;              % number of modes (initial:5)
DC = 1;             % include DC part (first mode at DC)

init = 0;           % initialize omegas randomly, may need multiple runs!

tol = 2.5*10^-4;      % tolerance (for convergence)10^-6
N = 100;     % number of iterations 500
%% run NVMD process
tic
[u, u_hat, omega,u_diff] = VMD_2D_nonnegative(f, alpha, tau, K, DC, init, tol,N);
toc

%% Visualization
figure('Name', 'Input image');
imagesc(f);
colormap gray;
axis equal;
axis off;

figure('Name', 'Input spectrum');
% imagesc(abs(fftshift(fft2(f))));
imagesc(log(abs(fftshift(fft2(f)))));
colormap gray;
axis equal;
axis off;
hold on;
colors = 'rbycmg';
for k = 1:size(omega,3)
    plot( size(f,2)*(0.5+omega(:,1,k)), size(f,1)*(0.5+omega(:,2,k)), colors(k) );
end

for k=1:size(u,3)
    figure('Name', ['Mode #' num2str(k)]);
    imagesc(u(:,:,k));
    colormap gray;
    axis equal;
    axis off;
end

figure('Name', 'Reconstructed composite');
imagesc(sum(u,3));
colormap gray;
axis equal;
axis off;

u_diff

%% Result extracted from mode #1
k = 0.3;    % Segmentation threshold; can be ajuested and adaptive
Result = u(:,:,1);
Result = Result > k;
figure('Name', 'Detection Result');
imshow(Result)





% Stable multi-subspace learning for infrared small target detection
% Reference:
% [1] Wang, Xiaoyang, et al. "Infrared Dim and Small Target Detection Based on Stable Multisubspace Learning in Heterogeneous Scene."
%   IEEE Transactions on Geoscience and Remote Sensing 55.10 (2017): 5481-5493.

%[2] Shu, Xianbiao, Fatih Porikli, and Narendra Ahuja. "Robust orthonormal subspace learning: Efficient recovery of corrupted low-rank matrices."
%   Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition. 2014.

% Author: Xiaoyang Wang (xywang1211@outlook.com)
% Date: Dec, 2015

clear all;close all

%% Multi-Subspace Learning

maxIter = 500;
tol = 1e-6;
lineSearchFlag=0;  continuationFlag=1;      %if continuationFlag=1, the input mu is invalidate
eta=0.99;
K=50;


% input test image
ii = 30;
I=imread(strcat(num2str((ii)),'.bmp'));
[p q z]=size(I);

% rgb2gray
if z==3
    I=rgb2gray(I);
end

% set patch size (adjustable)
m = 30;
n = 30;

% patch model
[D,endRow,endColumn]=patch_model(I,m,n);

[mm nn]=size(D);
% parameters setting
lambda =1/(sqrt(min(mm,nn)))*2;
mu=sqrt(2*max(mm,nn))*4;     % this value is related to the degree of noise

tic
[A_hat,E_hat,numIter,Dict,alpha,N_recovery] = proximal_gradient_rosl(D,K, lambda,maxIter, tol ,lineSearchFlag,continuationFlag,eta,mu);
toc

% reverse background and target image
corrupted=reverse_patch_model(E_hat,m,n,p,q,endRow,endColumn);  % target image
background=reverse_patch_model(A_hat,m,n,p,q,endRow,endColumn);

imshow(corrupted,[]);
figure;
imshow(background,[]);

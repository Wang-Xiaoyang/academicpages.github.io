%------  TV-PCP model for infrared small target detection ----------%
% Author: Xiaoyang Wang  ----------------------------------------%
% Date: Dec, 2015 -----------------------------------------------%
% Reference: (if you use this code, please cite the following reference)
% [1]  Xiaoyang Wang, Zhenming Peng*, Dehui Kong, Ping Zhang, Yanmin He. 
%  Infrared Dim Target Detection Based on Total Variation Regularization and Principal Component Pursuit[J]. Image and Vision Computing, 2017, 63: 1-9.
% [2]  Chenqiang Gao, Deyu Meng, Yi Yang, et. al. Infrared patch-image model for small target detection in a single image[J]. IEEE Trans. on Image Processing, 2013, 
%	22(12): 4996 -- 5009
%--------------------------------------------------------------%

clc; clear all; close all;
addpath('common');

% open an image
[filename,pathname]=uigetfile('*.bmp;*.jpg;*.png;','select the file');
img=[pathname,filename];
I=imread(img);

%% Infrared image model

[p q ch]=size(I);
if ch==3
    I=rgb2gray(I);
end

% patch size and step length
wx=50; wy=50;
SlidingStepX=14;SlidingStepY=14;
[D,EndRow,EndColumn]=ImagePatchModel(I,wx,wy,SlidingStepX,SlidingStepY);

[mm nn]=size(D);        

%% parameter setting for low-rank, TV and sparse recovery

% important parameters
lambda=0.005;
lambda2=1/(sqrt(min(mm,nn)));
maxIter = 250;%500
tol = 5e-6; %5e-6

beta=0.025;
gama=1.5;

clear pars
pars.MAXITER=50;       % Max Iter
pars.tv='iso'; % The value can be 'iso' or 'l1'; Default is 'iso';
pars.epsilon=1e-2;  % Stop criteria
pars.print=0;  % Show the iteration detail; If ==0, the detaile will not be showed

%set pars for TGV2

clear pars_TGV2
pars_TGV2.maxIter=100;
pars_TGV2.lambda=1.5;

%  mu=60;
 
%% low-rank, TV and sparse recovery

tic

%  Low rank, sparse and total variation constraint
% using TV in this example
[B,T,N] = TV_PCP_solver(D,lambda,lambda2,beta,gama,tol,maxIter,'TV',pars,pars_TGV2);

time_count=toc
% 

%% Showing results

background=ImagePatchReconstructionV2(B,I,EndRow,EndColumn,wx,wy,SlidingStepX,SlidingStepY);
corrupted=ImagePatchReconstructionV2(T,I,EndRow,EndColumn,wx,wy,SlidingStepX,SlidingStepY);
noise_recovered=ImagePatchReconstructionV2(N,I,EndRow,EndColumn,wx,wy,SlidingStepX,SlidingStepY);


figure; imshow(background,[]);title('background')
figure; imshow(corrupted,[]);title('target')
figure; imshow(I);


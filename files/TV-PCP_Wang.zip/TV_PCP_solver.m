% Author: Xiaoyang Wang
% Date: Dec, 2015 -----------------------------------------------%
% Reference: (if you use this code, please cite the following reference)
%   Xiaoyang Wang, Zhenming Peng*, Dehui Kong, Ping Zhang, Yanmin He. 
%  Infrared Dim Target Detection Based on Total Variation Regularization and Principal Component Pursuit[J]. Image and Vision Computing, 2017, 63: 1-9.

function [B,T,N]=TV_PCP_solver(I,lambda,lambda2,beta,gama,tol,maxIter,Type,pars,pars_TGV2)
[m n]=size(I);
delta=1;
%% initialize
B_k=zeros(m,n);     B_kp1=zeros(m,n);
T_k=zeros(m,n);     T_kp1=zeros(m,n);

Y1=zeros(m,n);       Y2=zeros(m,n);
Y3=zeros(m,n);      Y4=zeros(m,n);

I_norm=norm(I,'fro');

converged=false;
iter=0;

while ~converged       
    
    iter = iter + 1;
    
    B_k=B_kp1;
    T_k=T_kp1;
    
    
    [U S V]=svd(B_k-Y1/beta,'econ');
    diagS=diag(S);
    
    Z1_kp1=U * diag(pos(diagS-1/beta)) * V';
    
%     Z1_kp1=U*diag(max(diagS-1/beta,0))*V';
    
    if strcmp(Type,'TV')==1
    Z2_kp1=denoise_bound((B_k-Y2/beta),lambda/beta,-Inf,Inf,pars);
    else if strcmp(Type,'TGV2')==1
            Z2_kp1=primal_dual_TGVL2 ((B_k-Y2/beta),pars_TGV2.lambda, pars_TGV2.maxIter);
%             Z2_kp1=primal_dual_TGVL2 ((B_k-Y2/beta),beta/lambda, pars_TGV2.maxIter);
        end
    end
    
    Z3_kp1 = max(abs(T_k-Y3/beta)-lambda2/beta, 0).*sign(T_k-Y3/beta);
    
    pro=delta/norm((I-T_k-B_k+Y4/beta),'fro');
    
    if pro>=1
        N_kp1=I-T_k-B_k+Y4/beta;
    else
        N_kp1=pro*(I-T_k-B_k+Y4/beta);
    end
    
    B_kp1=(Y1+beta*Z1_kp1+Y2+beta*Z2_kp1+Y4+beta*(I-T_k-N_kp1))/(3*beta);
    
    T_kp1=(Y3+beta*Z3_kp1+Y4+beta*(I-B_kp1-N_kp1))/(2*beta);
    
    
    Y1=Y1+gama*beta*(Z1_kp1-B_kp1);
    Y2=Y2+gama*beta*(Z2_kp1-B_kp1);
    Y3=Y3+gama*beta*(Z3_kp1-T_kp1);
    Y4=Y4+gama*beta*(I-T_kp1-B_kp1-N_kp1);
    
    Error=I-T_kp1-B_kp1-N_kp1;

        
    %% stop Criterion    
    stopCriterion = norm(Error, 'fro') / I_norm;
    if stopCriterion < tol || iter >= maxIter
        converged = true;
    end 
    
    
         disp(['#Iter ' num2str(iter)...
            ' stopCriterion ' num2str(stopCriterion)]);
end

B=B_kp1;
T=T_kp1;
N=N_kp1;
%Computation of local contrast map
function [lcm_value]=LocalContrast(I,row,column,scale,cell_coding)
half=(scale-1)/2;
L=max(max(I((row-half):(row+half),(column-half):(column+half))));     %central cell
L=double(L);
cell_mean=zeros(8,1);
for ii=-1:1
    for jj=-1:1
        if ii==0 && jj==0
            continue
        end
        index_cell=cell_coding(ii+2,jj+2);
        current_cell=I((((row+ii*scale)-half):((row+ii*scale)+half)),(((column+jj*scale)-half):((column+jj*scale)+half)));
        cell_mean(index_cell)=mean(mean(current_cell));
    end
end
lcm_value=(L^2)/(max(cell_mean));
end

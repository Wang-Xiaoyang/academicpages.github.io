%
function [row,column,num]=binary2coordinate(I,size_u)
[m n]=size(I);
half=(size_u-1)/2;
index=find(I==1);
[row column]=ind2sub([m,n],index);      
num=length(row);
ii=1;
while (ii<=num)         
    if (row(ii)<=(size_u+half)) ||( column(ii)<=(size_u+half) )|| (row(ii)>(m-size_u-half ))||(column(ii)>(n-size_u-half))
        row(ii)=[];
        column(ii)=[];
        num=num-1;
    else
        ii=ii+1;
    end
end

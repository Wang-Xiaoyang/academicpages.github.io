function [result]=spatio_similarity(I,win_size,k)
[m,n,ch]=size(I);
if ch==3
    I=rgb2gray(I);
end
row_num=floor(m/win_size)*win_size;
column_num=floor(n/win_size)*win_size;
measure1=zeros(m,n);
measure2=zeros(m,n);

thres=k*win_size;

for ii=1:win_size:row_num-win_size+1                
    for jj=1:win_size:column_num-2*win_size+1
        left_patch=I(ii:ii+win_size-1,jj:jj+win_size-1);
        right_patch=I(ii:ii+win_size-1,jj+win_size:jj+2*win_size-1);
        temp=left_patch-right_patch;
        similarity=sqrt(sum(sum(temp.^2)));
        if similarity>=thres
            measure2(ii:ii+win_size-1,jj+win_size:jj+2*win_size-1)=1;
        else
            measure2(ii:ii+win_size-1,jj+win_size:jj+2*win_size-1)=0;        
        end
    end
end

for jj=1:win_size:column_num-win_size+1             
    for ii=1:win_size:row_num-2*win_size+1
        up_patch=I(ii:ii+win_size-1,jj:jj+win_size-1);
        down_patch=I(ii+win_size:ii+2*win_size-1,jj:jj+win_size-1);
        temp=up_patch-down_patch;
        similarity=sqrt(sum(sum(temp.^2)));         
        if similarity>=thres
            measure1(ii+win_size:ii+2*win_size-1,jj:jj+win_size-1)=1;
        else
            measure1(ii+win_size:ii+2*win_size-1,jj:jj+win_size-1)=0;        
        end
    end
end
result=measure1&measure2;
end

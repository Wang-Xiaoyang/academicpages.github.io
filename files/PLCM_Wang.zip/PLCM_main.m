%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Author: Wang, Xiaoyang
Reference:
Xiaoyang, W., Zhenming, P., Ping, Z., & Yeming, M. (2015). Infrared small dim target detection based on local contrast combined with region saliency. High Power Laser and Particle Beams, 27(9), 091005.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc; clear all; close all;

%% Input
I=imread('22.bmp');

figure; imshow(I); title('original image');
[m n ch]=size(I);
if ch==3
    I=rgb2gray(I);
end
figure; mesh(1:n,1:m,double(I));colorbar;

%% Entropy-based saliency region
tic
Ent=entropyfilt(I);
figure;mesh(Ent);colorbar
Ent_mean=mean(mean(Ent));
Ent_std=std2(Ent);
% k1:����ͼ���������ԵĲ���
k1=0.9;
thres_ent=Ent_mean+k1*Ent_std;
saliency_Ent=Ent>=thres_ent;
toc

figure;imshow(Ent,[]);
figure; imagesc(Ent);colorbar;
figure;imshow(saliency_Ent);

%% Similarity-based saliency region

win_size=5;
I=double(I);

k2=5;       % spatial similarity parameter

tic
similarity=spatio_similarity(I,win_size,k2);

saliency_region=saliency_Ent & similarity;
toc

figure;imshow(similarity,[]); title('similarity based saliency region');
figure;imshow(saliency_region,[]);title('saliency region');

%% Saliency-based LCM

size_min=3; size_max=9; interval=2;
contrast_map=zeros(m,n,(size_max-size_min)/interval+1);
cell_coding=[1,2,3;4,0,5;6,7,8];
[row,column,num]=binary2coordinate(saliency_region,size_max);       

tic
for size_u=size_min:interval:size_max
    index_scale=(size_u-size_min)/interval+1;
    for iii=1:num
        row_cor=row(iii);
        column_cor=column(iii);
        lcm=LocalContrast(I,row_cor,column_cor,size_u,cell_coding);
        contrast_map(row_cor,column_cor,index_scale)=lcm;
    end
end
toc


tic
final_contrast_map = max(contrast_map,[],3);
toc

%% 
k3=3.5;        % range from 1.6~5 in practice
LCM_mean=mean(mean(final_contrast_map));
std_contrast_map=std2(final_contrast_map);
thres=LCM_mean+k3*std_contrast_map;

detection_result=final_contrast_map>=thres;     
toc

figure; mesh(1:n,1:m,final_contrast_map);colorbar; title('contrast map');
figure; imshow(detection_result); title('detection result');





 
 
 
 
